
package sena11;



public class Sena11 {

    
    public static void main(String[] args) {
        
        int i = 0;
         while( i < 1000 ){
            System.out.println(+i);
             i++;
           
        }

    } 
}

// Profe las clases salen como el ejercicio 11, pero en la guia es el 12